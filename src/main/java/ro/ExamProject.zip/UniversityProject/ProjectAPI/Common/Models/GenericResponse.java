package ro.UniversityProject.ProjectAPI.Common.Models;

public class GenericResponse {
   public String token;
    public String message;
    public int statusCode;
}
