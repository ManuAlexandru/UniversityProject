package ro.UniversityProject.ProjectAPI.BLL.ViewModels;

public class FilterBooks {

    public String text;
}
