package ro.UniversityProject.ProjectAPI.BLL.ViewModels;

public class BookViewModel {

    public String Name;
    public String Author;
    public String Year;
}
